const passport = require("passport");
const User = require("../models/user");
const GoogleStrategy = require("passport-google-oauth2").Strategy;
require("dotenv").config();
passport.use(
  new GoogleStrategy(
    {
      clientID: process.env.GOOGLE_CLIENT_ID,
      clientSecret: process.env.GOOGLE_CLIENT_SECRET,
      callbackURL: "https://localhost:5000/user/google/callback",
      passReqToCallback: true,
    },

    function (request, accessToken, refreshToken, profile, done) {
      let { email, displayName, id } = profile;
      User.find({ email })
        .then((user) => {
          if (user.length) {
            //user exist
            console.log("user exist");
            return done(null, user);
          } else {
            const newUser = {
              email,
              fullName: displayName,
              googleId: id,
              accessToken,
            };
            // console.log("Request : " + accessToken);
            console.log(newUser);
            return done(null, newUser);
          }
        })
        .catch((err) => {
          console.log(err);
        });
    }
  )
);

passport.serializeUser(function (user, done) {
  done(null, user);
});

passport.deserializeUser(function (user, done) {
  done(null, user);
});
