// const cookieParser = require("cookie-parser");
const express = require("express");
const mongoose = require("mongoose");
const passport = require("passport");
const cors = require("cors");
const app = express();
require("dotenv").config();
const userRoutes = require("./routes/user");
require("./auth/passport-google");
require("./auth/passport-facebook");
mongoose
  .connect(process.env.MONGODB_URI, {
    useNewUrlParser: true,
    useUnifiedTopology: true,
    socketTimeoutMS: 0,
  })
  .then(() => console.log("Connexion à MongoDB réussie !"))
  .catch((e) => console.log(e));

app.use(express.json());
app.use(express.urlencoded({ extended: false }));

app.use(passport.initialize());

app.use((req, res, next) => {
  res.setHeader("Access-Control-Allow-Origin", "*");
  res.setHeader(
    "Access-Control-Allow-Headers",
    "Origin, X-Requested-With, Content, Accept, Content-Type, Authorization"
  );
  res.setHeader(
    "Access-Control-Allow-Methods",
    "GET, POST, PUT, DELETE, PATCH, OPTIONS"
  );
  next();
});

//authentification with google
app.get(
  "/user/auth/google",
  passport.authenticate("google", { scope: ["email", "profile"] })
);

app.get(
  "/user/google/callback",
  passport.authenticate("google", {
    session: false,
    successRedirect: "/taha",
    failureRedirect: "http://localhost:3000/login",
  })
);
//if the call of the oauth has been failed
app.get("/user/login", (req, res) => {
  res.send("login");
});

//configuration of the facebook auth
app.get("/user/auth/facebook", passport.authenticate("facebook"));
//then we will configure the facebook strategy callback
app.get(
  "/user/facebook/callback",
  passport.authenticate("facebook", {
    session: false,
    successRedirect: "http://localhost:3000?source=facebook",
    failureRedirect: "http://localhost:3000/login",
  })
);
app.use("/user", userRoutes);

module.exports = app;
