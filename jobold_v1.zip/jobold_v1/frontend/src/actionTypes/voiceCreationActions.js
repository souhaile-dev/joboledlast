export const updateMockUp = (resume) => ({
  type: "resume/updateMockUp",
  payload: resume,
});
