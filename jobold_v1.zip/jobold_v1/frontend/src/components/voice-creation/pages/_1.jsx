import React, { useState } from "react";

const _1 = () => {
  return <div className="hidden">1</div>;
};

export default _1;
