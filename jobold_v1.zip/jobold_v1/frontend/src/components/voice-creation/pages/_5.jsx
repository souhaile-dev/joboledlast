import React, { useState } from "react";

const _5 = () => {
  return <div className="hidden">1</div>;
};

export default _5;
