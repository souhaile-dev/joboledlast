import React from "react";

const MainSection = () => {
  return (
    <div className="h-full bg-[#f05209]">
      <h1>MainSection</h1>
    </div>
  );
};

export default MainSection;
