import React, { Component } from 'react'

export default class Jobs2 extends Component {
  render() {
    return (
        <div className="w-[1280px] h-[832px] relative bg-gray-100">
        <div className="w-[989px] h-[832px] left-[291px] top-0 absolute bg-white" />
        <img className="w-14 h-14 left-[1065px] top-[37px] absolute rounded-full" src="https://via.placeholder.com/56x56" />
        <div className="left-[1129px] top-[44px] absolute text-center text-black text-xl font-normal font-['Poppins']">Sed Barreth</div>
        <div className="left-[1129px] top-[69px] absolute text-center text-black text-xs font-normal font-['Poppins']">CEO</div>
        <div className="left-[34px] top-[138px] absolute text-center text-black text-base font-medium font-['Poppins']">Menu</div>
        <img className="w-48 h-[51px] left-[34px] top-[40px] absolute" src="https://via.placeholder.com/192x51" />
        <div className="left-[86px] top-[714px] absolute text-black text-xl font-normal font-['Poppins']">Settings</div>
        <div className="left-[86px] top-[764px] absolute text-black text-xl font-normal font-['Poppins']">Log Out</div>
        <div className="w-6 h-6 left-[47px] top-[767px] absolute">
        </div>
        <div className="w-[17.79px] h-[19.22px] left-[50px] top-[719px] absolute">
        </div>
        <div className="w-[216px] h-[57px] left-[34px] top-[559px] absolute bg-blue-500 rounded-[34px]" />
        <div className="left-[81px] top-[575px] absolute text-white text-base font-medium font-['Poppins']">Add new Job</div>
        <div className="w-[20.10px] h-[20.07px] left-[944px] top-[55px] absolute">
        </div>
        <div className="w-3.5 h-3.5 left-[953px] top-[50px] absolute bg-rose-500 rounded-full" />
        <div className="w-3.5 h-3.5 left-[1010px] top-[50px] absolute bg-rose-500 rounded-full" />
        <div className="left-[957px] top-[50px] absolute text-center text-white text-[10px] font-bold font-['Poppins']">7</div>
        <div className="left-[1012px] top-[50px] absolute text-center text-white text-[10px] font-bold font-['Poppins']">12</div>
        <div className="left-[86.27px] top-[664px] absolute text-black text-xl font-normal font-['Poppins']">Billing</div>
        <div className="w-[16.53px] h-[22.55px] left-[51px] top-[668px] absolute">
        </div>
        <div className="w-[216px] h-[57px] left-[34px] top-[462px] absolute bg-white rounded-[49px]" />
        <div className="left-[86px] top-[209px] absolute text-black text-xl font-normal font-['Poppins']">Dashboard</div>
        <div className="left-[86px] top-[262px] absolute text-black text-xl font-normal font-['Poppins']">Team</div>
        <div className="left-[86px] top-[315px] absolute text-black text-xl font-normal font-['Poppins']">Saved Profiles</div>
        <div className="left-[86px] top-[368px] absolute text-black text-xl font-normal font-['Poppins']">Schudule</div>
        <div className="w-[15px] h-[15px] left-[51px] top-[269px] absolute" />
        <div className="w-3 h-[13.33px] left-[52px] top-[376px] absolute">
        </div>
        <div className="left-[86px] top-[421px] absolute text-black text-xl font-normal font-['Poppins']">Company</div>
        <div className="left-[86px] top-[474px] absolute text-black text-xl font-normal font-['Poppins']">Jobs</div>
        <div className="w-4 h-[14.55px] left-[50px] top-[482px] absolute">
        </div>
        <div className="w-2.5 h-[724px] left-[1270px] top-[104px] absolute bg-gray-100" />
        <div className="w-2.5 h-[389px] left-[1270px] top-[104px] absolute bg-violet-700" />
        <div className="left-[371px] top-[42px] absolute text-black text-4xl font-normal font-['Space Grotesk']">Candidates</div>
        <div className="w-[18px] h-[18px] left-[742px] top-[780px] absolute">
          <div className="w-[18px] h-[18px] left-0 top-0 absolute bg-blue-500 rounded-full" />
        </div>
        <div className="origin-top-left -rotate-180 w-[18px] h-[18px] left-[838px] top-[798px] absolute">
          <div className="w-[18px] h-[18px] left-0 top-0 absolute origin-top-left -rotate-180 bg-blue-500 bg-opacity-50 rounded-full" />
        </div>
        <div className="left-[775px] top-[780px] absolute text-black text-xs font-normal font-['Poppins']">1 of 7</div>
        <div className="left-[351px] top-[132px] absolute text-black text-base font-medium font-['Poppins']">Company</div>
        <div className="left-[379px] top-[252px] absolute text-violet-700 text-sm font-bold font-['Poppins']">Totale(126)</div>
        <div className="left-[584px] top-[252px] absolute text-black text-sm font-normal font-['Poppins']">New(43)</div>
        <div className="left-[752px] top-[252px] absolute text-black text-sm font-normal font-['Poppins']">Rejected(23)</div>
        <div className="left-[650px] top-[132px] absolute text-black text-base font-medium font-['Poppins']">Job title</div>
        <div className="w-[269px] h-[50px] left-[625px] top-[161px] absolute bg-gray-100 rounded-[30px]" />
        <div className="w-[311px] h-[50px] left-[924px] top-[161px] absolute bg-gray-100 rounded-[30px]" />
        <div className="w-[155.50px] h-[50px] left-[924px] top-[161px] absolute bg-violet-700 rounded-tl-[30px] rounded-bl-[30px]" />
        <div className="w-[269px] h-[50px] left-[326px] top-[164px] absolute bg-gray-100 rounded-[30px]" />
        <div className="left-[650px] top-[175px] absolute opacity-70 text-black text-sm font-normal font-['Poppins']">Community Manager</div>
        <div className="left-[351px] top-[178px] absolute opacity-70 text-black text-sm font-normal font-['Poppins']">Market Poke</div>
        <div className="left-[949px] top-[176px] absolute text-white text-base font-bold font-['Montserrat']">Applicants</div>
        <div className="left-[1104px] top-[176px] absolute text-black text-base font-bold font-['Montserrat']">Matches</div>
        <div className="w-[921px] h-[95px] left-[326px] top-[333px] absolute bg-gray-100 rounded-[66px]" />
        <div className="w-[921px] h-[95px] left-[326px] top-[438px] absolute bg-gray-100 rounded-[66px]" />
        <div className="w-[921px] h-[95px] left-[326px] top-[543px] absolute bg-gray-100 rounded-[66px]" />
        <div className="w-[921px] h-[95px] left-[326px] top-[648px] absolute bg-gray-100 rounded-[66px]" />
        <img className="w-[73px] h-[74px] left-[339px] top-[554px] absolute rounded-full" src="https://via.placeholder.com/73x74" />
        <img className="w-[73px] h-[75px] left-[339px] top-[343px] absolute rounded-full" src="https://via.placeholder.com/73x75" />
        <img className="w-[73px] h-[75px] left-[339px] top-[658px] absolute rounded-full" src="https://via.placeholder.com/73x75" />
        <img className="w-[73px] h-[74px] left-[339px] top-[449px] absolute rounded-full" src="https://via.placeholder.com/73x74" />
        <div className="left-[434px] top-[567px] absolute text-black text-xl font-normal font-['Poppins']">Lily Chen</div>
        <div className="left-[434px] top-[356px] absolute text-black text-xl font-normal font-['Poppins']">Jada Williams</div>
        <div className="left-[434px] top-[671px] absolute text-black text-xl font-normal font-['Poppins']">Ethan Patel</div>
        <div className="left-[434px] top-[461px] absolute text-black text-xl font-normal font-['Poppins']">Jasmin Robbert</div>
        <div className="left-[434px] top-[597px] absolute text-black text-xs font-normal font-['Poppins']">HR Generalist</div>
        <div className="left-[434px] top-[386px] absolute text-black text-xs font-normal font-['Poppins']">Software Developer</div>
        <div className="left-[434px] top-[701px] absolute text-black text-xs font-normal font-['Poppins']">Mobile Developer</div>
        <div className="left-[434px] top-[491px] absolute text-black text-xs font-normal font-['Poppins']">Software Developer</div>
        <div className="left-[614px] top-[588px] absolute text-black text-xs font-normal font-['Poppins']">3 years of experience</div>
        <div className="left-[614px] top-[372px] absolute text-black text-xs font-normal font-['Poppins']">14 years of experience</div>
        <div className="left-[614px] top-[687px] absolute text-black text-xs font-normal font-['Poppins']">9 years of experience</div>
        <div className="left-[614px] top-[477px] absolute text-black text-xs font-normal font-['Poppins']">2 years of experience</div>
        <div className="left-[799px] top-[585px] absolute text-violet-700 text-base font-medium font-['Poppins']">75 % Match</div>
        <div className="left-[799px] top-[369px] absolute text-violet-700 text-base font-medium font-['Poppins']">71 % Match</div>
        <div className="left-[799px] top-[684px] absolute text-violet-700 text-base font-medium font-['Poppins']">80 % Match</div>
        <div className="left-[799px] top-[474px] absolute text-violet-700 text-base font-medium font-['Poppins']">65 % Match</div>
        <div className="left-[1087px] top-[306px] absolute text-violet-700 text-xs font-normal font-['Poppins']">Export Resume</div>
        <div className="w-[88px] h-[0px] left-[1088px] top-[323px] absolute border border-violet-700"></div>
        <div className="left-[951px] top-[249px] absolute text-black text-opacity-70 text-base font-medium font-['Poppins']">Search by keywords</div>
        <div className="w-[138px] h-[43px] left-[1083px] top-[359px] absolute bg-blue-500 rounded-[34px]" />
        <div className="w-[138px] h-[43px] left-[1083px] top-[464px] absolute bg-blue-500 rounded-[34px]" />
        <div className="w-[138px] h-[43px] left-[1083px] top-[569px] absolute bg-blue-500 rounded-[34px]" />
        <div className="w-[138px] h-[43px] left-[1083px] top-[674px] absolute bg-blue-500 rounded-[34px]" />
        <div className="left-[1132px] top-[370px] absolute text-white text-base font-bold font-['Montserrat']">View</div>
        <div className="left-[1132px] top-[475px] absolute text-white text-base font-bold font-['Montserrat']">View</div>
        <div className="left-[1132px] top-[580px] absolute text-white text-base font-bold font-['Montserrat']">View</div>
        <div className="left-[1132px] top-[685px] absolute text-white text-base font-bold font-['Montserrat']">View</div>
        <div className="left-[1011px] top-[370px] absolute text-black text-sm font-normal font-['Poppins']">Reject</div>
        <div className="left-[1011px] top-[475px] absolute text-black text-sm font-normal font-['Poppins']">Reject</div>
        <div className="left-[1011px] top-[580px] absolute text-black text-sm font-normal font-['Poppins']">Reject</div>
        <div className="left-[1011px] top-[685px] absolute text-black text-sm font-normal font-['Poppins']">Reject</div>
      </div>
    )
  }
}
